package com.snhu.sslserver;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

	// This is your new route
	@GetMapping("/hash")
	public String getHash() throws NoSuchAlgorithmException {

		// 👇 PUT YOUR NAME + UNIQUE STRING HERE
		String data = "Cristiana Rodriguez - CS305 Project Two - 2026";

		// SHA-256 hashing
		MessageDigest digest = MessageDigest.getInstance("SHA-256");
		byte[] hashBytes = digest.digest(data.getBytes(StandardCharsets.UTF_8));

		// Convert to hex string
		StringBuilder hexString = new StringBuilder();
		for (byte b : hashBytes) {
			String hex = Integer.toHexString(0xff & b);
			if (hex.length() == 1) {
				hexString.append('0');
			}
			hexString.append(hex);
		}

		// Return results in browser
		return "<html><body>"
				+ "<h2>Original Data:</h2><p>" + data + "</p>"
				+ "<h2>SHA-256 Checksum:</h2><p>" + hexString.toString() + "</p>"
				+ "</body></html>";
	}
}